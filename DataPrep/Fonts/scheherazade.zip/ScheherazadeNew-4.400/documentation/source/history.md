---
title: Scheherazade New - Version History
fontversion: 4.400
---

### 2025-08-11 (SIL WSTech team) Scheherazade New version 4.400

#### New

- Added:
  - 088F ARABIC LETTER NOON WITH RING ABOVE
  - FBC6 ARABIC LIGATURE RAHMATU ALLAAHI ALAYHIM 
  - FBC7 ARABIC LIGATURE RAHMATU ALLAAHI ALAYHIMAA 
  - FD90 ARABIC LIGATURE RAHMATU ALLAAHI ALAYH 
  - FD91 ARABIC LIGATURE RAHMATU ALLAAHI ALAYHAA 
  - 10EC5 ARABIC SMALL YEH BARREE WITH TWO DOTS BELOW 
  - 10EC6 ARABIC LETTER THIN NOON 
  - 10EC7 ARABIC LETTER YEH WITH FOUR DOTS BELOW 
  - 10ED0 ARABIC BIBLICAL END OF VERSE 
  - 10EFA ARABIC DOUBLE VERTICAL BAR BELOW 
  - 10EFB ARABIC SMALL LOW NOON 
- Added cv88 (Guillemet) to provide a choice for angled guillemot characters in Arabic script
- Added Malay Jawi language support

#### Improved

- Added sample strings and feature tooltips to the character variants for applications that support them
- Minor anchor adjustment to final heh on Allah ligature
- Fix design of simplified form U+FDCF ARABIC LIGATURE SALAAMUHU ALAYNAA in Medium and SemiBold weights

#### Known issues

- Shaping for the newly added characters may not yet occur in applications.
- Medial and final high hamza characters may have collisions (these likely do not occur).
- Lam + high hamza alef ligature does not form as it likely does not occur.
- In InDesign: some behaviors, such as the _lam-alef_ ligature, raised _kasra_ with _shadda_, and subtending marks, will not function correctly unless **Ligatures** is turned on in the **Characters** panel.

### 2024-10-21 (SIL WSTech team) Scheherazade New version 4.300

#### New

- Added:
  - U+0897 ARABIC PEPET
  - U+10EC2 ARABIC LETTER DAL WITH TWO DOTS VERTICALLY BELOW
  - U+10EC3 ARABIC LETTER TAH WITH TWO DOTS VERTICALLY BELOW
  - U+10EC4 ARABIC LETTER KAF WITH TWO DOTS VERTICALLY BELOW
  - U+10EFC ARABIC COMBINING ALEF OVERLAY
- Added support for Kashmiri language
- Added facility to override default language behavior through feature selection
- Added support for cv76 (dagger alef) on spacing characters and tatweel

#### Improved

- Minor anchor adjustment on U+06D6
- Enhanced positioning of U+06E2 ARABIC SMALL HIGH MEEM ISOLATED FORM next to adjacent vowel marks
- Tweaks to the design of some of the honorifics
- Improved alef+mark positioning to reduce collisions
- Improved madda reordering to comply with UAX #53
- Documentation enhancements

### 2023-04-14 (SIL WSTech team) Scheherazade New version 4.000

#### New
- Added Medium and SemiBold weights
- Added Arabic-style (rounded) versions of chevron quotes
- Added Bold calligraphic honorifics (previous ones were the same weight as Regular)
- Added:
  - U+201B SINGLE HIGH-REVERSED-9 QUOTATION MARK
  - U+201F DOUBLE HIGH-REVERSED-9 QUOTATION MARK
  - U+10EFD ARABIC SMALL LOW WORD SAKTA
  - U+10EFE ARABIC SMALL LOW WORD QASR
  - U+10EFF ARABIC SMALL LOW WORD MADDA
- New features:
  - cv49 - Heh Doachashmee

#### Improved
- Changed Kurdish language to support a U+06BE Heh Doachashmee alternate rather than U+0647 Heh alternate
- Redesigned
  - U+0616 ARABIC SMALL HIGH LIGATURE ALEF WITH LAM WITH YEH (see [https://www.unicode.org/versions/Unicode15.0.0/erratafixed.html](https://www.unicode.org/versions/Unicode15.0.0/erratafixed.html))
  - Slight adjustments to:
    - gaf-like characters (such as U+06AF ARABIC LETTER GAF)
    - U+0601 ARABIC SIGN SANAH
    - U+0605 ARABIC NUMBER MARK ABOVE
- Small improvements to kerning

#### Removed
- Removed support for Sindhi-style comma when Sindhi language is selected
- Removed Graphite support

#### Known issues
- Shaping for the newly added characters may not yet occur in applications
- Medial and final high hamza characters may have collisions (these likely do not occur)
- Lam + high hamza alef ligature does not form as it likely does not occur

### 2021-11-22 (SIL WSTech team) Scheherazade New Version 3.300 (official release)
- Added U+0870..U+088E, U+0890..U+0891, U+0898..U+089F, U+08B5, U+08C8..U+08D2
- Added bold version of glyph for U+08AD ARABIC LETTER LOW ALEF
- Added decimal separator feature (cv85)
- Added a longer kashida for cases where diacritics are above or below U+0640 ARABIC TATWEEL
- Revised rules for forming Allah ligature

### 2021-07-15 (SIL WSTech team) Scheherazade New Version 3.200 (official release)
- Double-encoded honorifics to use both PUA codepoints and official Unicode 14.0 codepoints

### 2021-03-26 (SIL WSTech team) Scheherazade New Version 3.100 (official release)
- Fixed Graphite bug related to spacing of U+2E41
- Fixed OpenType bug with diacritic position (in the context of a shadda) on lam-alef
- Fixed OpenType bug in context of kashida insertion (affected diacritics and spacing)
- Fixed misencoded Delta (U+2209 to U+2206)
- Fixed TypeTuner bug related to shadda+kasra feature
- Added and implemented support for U+08E2 DISPUTED END OF AYAH
- Added two more honorific ligatures
- Updated design of most simple spelled forms of honorific ligatures
- Created calligraphic forms of honorific ligatures
- Added feature cv81, Honorific ligatures, to support turning on simple forms of honorific ligatures

### 2020-11-5 (SIL WSTech team) Scheherazade New Version 3.000 (official release)
- Renamed font to Scheherazade New
- Resized glyphs to better fit standard Arabic script fonts
- Adjusted line-spacing to reflect larger characters
- Adjusted underline and strikethrough positions and weight
- Updated Arabic script character repertoire to support all characters in the Unicode 13.0 BMP Arabic blocks (except for U+08E2 disputed end of ayah)
- Updated Latin script repertoire to support "Recommended characters for Non-Roman fonts" https://scriptsource.org/entry/gg5wm9hhd3
- Added U+204F and U+2E41 for Sindhi language support
- Added U+FDFA (sallallahou alayhe wasallam), U+FDFB (jallajalalouhou), and U+FDFD (bismillah)
- Added Private Use Area honorific ligatures (all of these are in the Unicode pipeline at non-stable codepoints).
- Adjusted vertical position of isolate keheh-like characters
- Changed design of small v and inverted small v characters (U+063D, U+065A, U+065B, U+0692, U+06B5, U+06C9, U+06CE, U+06EE, U+06EF, U+06FF, U+0756, U+0769, U+077E, U+08B2, U+08BE..U+08C2)
- Changed design of U+06C5 for Kyrgyz language and added feature cv51, Kyrgyz OE,	supporting the bar design
- Changed design of U+0677 and U+06C7
- Changed design of high hamza characters (U+0674..U+0678)
- Adjusted the weight and position of some dashes to make them consistent
- Implemented new Allah ligature rules
- Implemented support for UNICODE ARABIC MARK RENDERING (UTR #53) 
- Improved kerning - reh/waw, lam-alef ligature, AE+kaf-like initials, and others
- Added collision fixes for certain combinations
- Fixed bug in forming of lam/alef ligatures when automatic kashida justification is turned on
- Added UI name strings for Graphite and OpenType features
- Removed support for Sindhi-style heh when Sindhi language is selected
- Removed support for Urdu-style heh when Urdu language is selected
- Removed "Arabic U" feature
- Removed "Show invisible characters" feature
- Removed "Jeh hack" feature
- Removed "Dotless head of Khah hack" feature
- Added feature cv54, Yeh hamza, for Kyrgyz language
- Added Kyrgyz language support in Graphite and OpenType
- Added Wolof language support in Graphite and OpenType
- Added support for Comma downward when Sindhi language is selected

### 2015-08-19 (SIL NRSI team) Scheherazade Version 2.100 (official release)
- Renamed postscript name of Scheherazade Regular from "Scheherazade" to "Scheherazade-Regular"

### 2015-07-17 (SIL NRSI team) Scheherazade Version 2.092 (test release)
- Added Scheherazade Bold font
- Slight improvements in design of the Regular face:
   - 060C ARABIC COMMA
   - 061B ARABIC SEMICOLON
   - 065D ARABIC REVERSED DAMMA
   - 0671 ARABIC LETTER ALEF WASLA (improvement in wasla)
   - 06C1 ARABIC LETTER HEH GOAL
   - 08AA ARABIC LETTER REH WITH LOOP
- Diacritic selection feature of Graphite removed; fixed feature name/value string mismatches
- Adjusted sidebearings for U+06EF and U+08B2 to be more consistent
- Fix OT Character variants to work in all language tags
- Small kerning adjustments
- Added three Unicode 8.0 characters
    - 08B3 ARABIC LETTER AIN WITH THREE DOTS BELOW
    - 08B4 ARABIC LETTER KAF WITH DOT BELOW
    - 08E3 ARABIC TURNED DAMMA BELOW
- Added five characters that are not officially in Unicode. They are in the "pipeline." 
    - 08B6 ARABIC LETTER BEH WITH SMALL MEEM ABOVE
    - 08B7 ARABIC LETTER PEH WITH SMALL MEEM ABOVE
    - 08B8 ARABIC LETTER TEH WITH SMALL TEH ABOVE
    - 08B9 ARABIC LETTER REH WITH SMALL NOON ABOVE
    - 08BA ARABIC LETTER YEH WITH TWO DOTS BELOW AND SMALL NOON ABOVE
    - 08BB ARABIC LETTER AFRICAN FEH
    - 08BC ARABIC LETTER AFRICAN QAF
    - 08BD ARABIC LETTER AFRICAN NOON

### 2014-02-12 (SIL NRSI team) Scheherazade Version 2.020 (maintenance release)
- Fix language-specific OpenType rendering for Sindhi, Urdu, Kurdish

### 2013-09-11 (SIL NRSI team) Scheherazade Version 2.010 (maintenance release)
- Fix rendering of mixtures of upper and lower combining marks
- Fix Graphite shaping for U+08AC ARABIC LETTER ROHINGYA YEH
- Reduce font size by taking advantage of composite TT glyphs

### 2013-08-01 (SIL NRSI team) Scheherazade Version 2.000 (official release)
- Removed white on black glyph for full stop

### 2013-07-15 (SIL NRSI team) Scheherazade Version 1.940 (test release)
- Kerning added for reh-like and waw-like characters 
- Added five characters that are not officially in Unicode. They are in the "pipeline." 
    - 061C ARABIC LETTER MARK (ALM)
    - 2066 LEFT-TO-RIGHT ISOLATE
    - 2067 RIGHT-TO-LEFT ISOLATE
    - 2068 FIRST STRONG ISOLATE
    - 2069 POP DIRECTIONAL ISOLATE
- 0603 now supports up to 4 digits
- fixed lam+alef collisions with combining marks below 
- upper vowel changed to render below maddah (except for 065E)
    
### 2013-04-18 (SIL NRSI team) Scheherazade Version 1.930 (test release)
- Typetuner now adjusts Graphite features as well as OpenType 

### 2013-03-05 (SIL NRSI team) Scheherazade Version 1.920 (test release)
- Added Rohingya language
- Shaping for Subtending marks fixed
- Added line spacing feature for TypeTuner only
- Moved U+065E ARABIC FATHA WITH TWO DOTS to proper position between maddah and alef

### 2013-01-08 (SIL NRSI team) Scheherazade Version 1.910 (test release)
- Improved positioning and size of dagger-alef (U+0670)
- Added feature to access variant glyphs for Superscript Alef (default is small)
- Added Rohingya-style variant to Eastern digits feature
- Improved design of FDF2
- Some improvement in collision avoidance
- Shaping for Subtending marks fixed
- Changed glyph design of Urdu-style U+06F4
- Fixed position of hamza with U+06B8 + U+0625 are in isolate form
- Made U+06BA Arabic Letter Noon Ghunna dotless in all forms

### 2012-09-18 (SIL NRSI team) Scheherazade Version 1.900 (test release)
- Improved positioning of combining marks
- Improved positioning and size of dagger-alef (U+0670)
- Added support for Unicode 5.1, 6.0 and 6.1 Arabic additions
- Added eight characters that are not officially in Unicode. They are in the "pipeline." Please note that there is a slight possibility that these codepoints could change.
    - 08A1 ARABIC LETTER BEH WITH HAMZA ABOVE
    - 08AD ARABIC LETTER LOW ALEF
    - 08AE ARABIC LETTER DAL WITH THREE DOTS BELOW
    - 08AF ARABIC LETTER SAD WITH THREE DOTS BELOW
    - 08B0 ARABIC LETTER GAF WITH INVERTED STROKE
    - 08B1 ARABIC LETTER STRAIGHT WAW
    - 08B2 ARABIC LETTER ZAIN WITH INVERTED V ABOVE
    - 08FF ARABIC MARK SIDEWAYS NOON GHUNNA
- Changed glyph design for U+06F4 EXTENDED ARABIC-INDIC DIGIT FOUR
- Changed default maddah to be smaller size (as mentioned below, ability to change back to larger size was added)
- Added OpenType support for character variants
- Added Graphite support
- Added TypeTuner features to access variant glyphs for:
		- Dal, Meem, Heh, Arabic U, Maddah, Damma, Inverted Damma, Eastern digits
- Renamed TypeTuner features for:
	  - Six-nine dammatan > Dammatan
	  - Downward comma > Comma
	  - Jeh > Jeh-hack
	  - Dotless head of khah > Dotless head of khah hack
- Removed TypeTuner feature for Old Shina hack	  
- Removed AAT support

### 2011-02-07 (SIL NRSI team) Scheherazade Version 1.005
- Added TypeTuner feature to access jeh alternate
- Added developer release

### 2009-09-01 (SIL NRSI team) Scheherazade Version 1.004
- Added TypeTuner feature to access language alternates

### 2009-02-04 (SIL NRSI team) Scheherazade Version 1.003
- Added TypeTuner feature to control shadda+kasra rendering

2008-10-25 (SIL NRSI team) Scheherazade Version 1.002
- Added TypeTuner table with Shina hacks

### 2007-06-21 (SIL NRSI team) Scheherazade Version 1.001
- Re-released under OFL
- no other changes from 1.0

### 2005-06-03 (SIL NRSI team) Scheherazade Version 1.0
- First public version
- Released under the SIL Freeware License


